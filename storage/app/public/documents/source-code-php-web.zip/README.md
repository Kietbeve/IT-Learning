# Phone Shop PHP Web

Đây là mã nguồn website bán hàng viết bằng PHP thuần kết nối MySQL PDO.

## Cài đặt:
1. Import database.sql vào phpMyAdmin.
2. Cấu hình config.php.
3. Chạy trên XAMPP.